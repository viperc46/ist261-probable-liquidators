﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmGrideye
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.lblGridEye = New System.Windows.Forms.Label()
        Me.btnPrevious = New System.Windows.Forms.Button()
        Me.btnNext = New System.Windows.Forms.Button()
        Me.txtHint = New System.Windows.Forms.TextBox()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.BtnGridBack = New System.Windows.Forms.Button()
        Me.BtnReset = New System.Windows.Forms.Button()
        Me.btnGrid1 = New System.Windows.Forms.Button()
        Me.btnGrid2 = New System.Windows.Forms.Button()
        Me.btnGrid3 = New System.Windows.Forms.Button()
        Me.btnGrid4 = New System.Windows.Forms.Button()
        Me.btnGrid5 = New System.Windows.Forms.Button()
        Me.btnGrid6 = New System.Windows.Forms.Button()
        Me.btnGrid7 = New System.Windows.Forms.Button()
        Me.btnGrid8 = New System.Windows.Forms.Button()
        Me.btnGrid9 = New System.Windows.Forms.Button()
        Me.btnGrid10 = New System.Windows.Forms.Button()
        Me.btnGrid11 = New System.Windows.Forms.Button()
        Me.btnGrid12 = New System.Windows.Forms.Button()
        Me.btnGrid13 = New System.Windows.Forms.Button()
        Me.btnGrid14 = New System.Windows.Forms.Button()
        Me.btnGrid15 = New System.Windows.Forms.Button()
        Me.btnGrid16 = New System.Windows.Forms.Button()
        Me.btnGrid17 = New System.Windows.Forms.Button()
        Me.btnGrid18 = New System.Windows.Forms.Button()
        Me.btnGrid19 = New System.Windows.Forms.Button()
        Me.btnGrid20 = New System.Windows.Forms.Button()
        Me.btnGrid21 = New System.Windows.Forms.Button()
        Me.btnGrid22 = New System.Windows.Forms.Button()
        Me.btnGrid23 = New System.Windows.Forms.Button()
        Me.btnGrid24 = New System.Windows.Forms.Button()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.txtCheck = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblGridEye
        '
        Me.lblGridEye.AutoSize = True
        Me.lblGridEye.Location = New System.Drawing.Point(550, 383)
        Me.lblGridEye.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.lblGridEye.Name = "lblGridEye"
        Me.lblGridEye.Size = New System.Drawing.Size(121, 20)
        Me.lblGridEye.TabIndex = 1
        Me.lblGridEye.Text = "Grid Eye Puzzle"
        '
        'btnPrevious
        '
        Me.btnPrevious.BackColor = System.Drawing.Color.CornflowerBlue
        Me.btnPrevious.Location = New System.Drawing.Point(94, 509)
        Me.btnPrevious.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnPrevious.Name = "btnPrevious"
        Me.btnPrevious.Size = New System.Drawing.Size(198, 69)
        Me.btnPrevious.TabIndex = 2
        Me.btnPrevious.Text = "Previous"
        Me.btnPrevious.UseVisualStyleBackColor = False
        '
        'btnNext
        '
        Me.btnNext.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnNext.Location = New System.Drawing.Point(900, 509)
        Me.btnNext.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnNext.Name = "btnNext"
        Me.btnNext.Size = New System.Drawing.Size(198, 69)
        Me.btnNext.TabIndex = 3
        Me.btnNext.Text = "Next Hint"
        Me.btnNext.UseVisualStyleBackColor = False
        '
        'txtHint
        '
        Me.txtHint.Location = New System.Drawing.Point(392, 449)
        Me.txtHint.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtHint.Multiline = True
        Me.txtHint.Name = "txtHint"
        Me.txtHint.Size = New System.Drawing.Size(416, 127)
        Me.txtHint.TabIndex = 4
        Me.txtHint.Text = "Hints will go here..."
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.DodgerBlue
        Me.btnBack.Location = New System.Drawing.Point(-2, -2)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(112, 35)
        Me.btnBack.TabIndex = 5
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'BtnGridBack
        '
        Me.BtnGridBack.BackColor = System.Drawing.Color.DodgerBlue
        Me.BtnGridBack.Location = New System.Drawing.Point(0, 0)
        Me.BtnGridBack.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BtnGridBack.Name = "BtnGridBack"
        Me.BtnGridBack.Size = New System.Drawing.Size(112, 35)
        Me.BtnGridBack.TabIndex = 6
        Me.BtnGridBack.Text = "Back"
        Me.BtnGridBack.UseVisualStyleBackColor = False
        '
        'BtnReset
        '
        Me.BtnReset.BackColor = System.Drawing.Color.LightSlateGray
        Me.BtnReset.Location = New System.Drawing.Point(94, 383)
        Me.BtnReset.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.BtnReset.Name = "BtnReset"
        Me.BtnReset.Size = New System.Drawing.Size(198, 69)
        Me.BtnReset.TabIndex = 7
        Me.BtnReset.Text = "Reset Puzzle"
        Me.BtnReset.UseVisualStyleBackColor = False
        '
        'btnGrid1
        '
        Me.btnGrid1.Location = New System.Drawing.Point(57, 74)
        Me.btnGrid1.Name = "btnGrid1"
        Me.btnGrid1.Size = New System.Drawing.Size(108, 46)
        Me.btnGrid1.TabIndex = 8
        Me.btnGrid1.Text = "murder"
        Me.btnGrid1.TextImageRelation = System.Windows.Forms.TextImageRelation.TextAboveImage
        Me.btnGrid1.UseVisualStyleBackColor = True
        '
        'btnGrid2
        '
        Me.btnGrid2.Location = New System.Drawing.Point(260, 74)
        Me.btnGrid2.Name = "btnGrid2"
        Me.btnGrid2.Size = New System.Drawing.Size(110, 46)
        Me.btnGrid2.TabIndex = 9
        Me.btnGrid2.Text = "ventriloquism"
        Me.btnGrid2.UseVisualStyleBackColor = True
        '
        'btnGrid3
        '
        Me.btnGrid3.Location = New System.Drawing.Point(477, 74)
        Me.btnGrid3.Name = "btnGrid3"
        Me.btnGrid3.Size = New System.Drawing.Size(94, 46)
        Me.btnGrid3.TabIndex = 10
        Me.btnGrid3.Text = "dark"
        Me.btnGrid3.UseVisualStyleBackColor = True
        '
        'btnGrid4
        '
        Me.btnGrid4.Location = New System.Drawing.Point(680, 74)
        Me.btnGrid4.Name = "btnGrid4"
        Me.btnGrid4.Size = New System.Drawing.Size(93, 46)
        Me.btnGrid4.TabIndex = 11
        Me.btnGrid4.Text = "heighten"
        Me.btnGrid4.UseVisualStyleBackColor = True
        '
        'btnGrid5
        '
        Me.btnGrid5.Location = New System.Drawing.Point(877, 74)
        Me.btnGrid5.Name = "btnGrid5"
        Me.btnGrid5.Size = New System.Drawing.Size(98, 46)
        Me.btnGrid5.TabIndex = 12
        Me.btnGrid5.Text = "bullseye"
        Me.btnGrid5.UseVisualStyleBackColor = True
        '
        'btnGrid6
        '
        Me.btnGrid6.Location = New System.Drawing.Point(57, 149)
        Me.btnGrid6.Name = "btnGrid6"
        Me.btnGrid6.Size = New System.Drawing.Size(108, 45)
        Me.btnGrid6.TabIndex = 13
        Me.btnGrid6.Text = "Dusty"
        Me.btnGrid6.UseVisualStyleBackColor = True
        '
        'btnGrid7
        '
        Me.btnGrid7.Location = New System.Drawing.Point(260, 149)
        Me.btnGrid7.Name = "btnGrid7"
        Me.btnGrid7.Size = New System.Drawing.Size(110, 45)
        Me.btnGrid7.TabIndex = 14
        Me.btnGrid7.Text = "voodoo"
        Me.btnGrid7.UseVisualStyleBackColor = True
        '
        'btnGrid8
        '
        Me.btnGrid8.Location = New System.Drawing.Point(477, 149)
        Me.btnGrid8.Name = "btnGrid8"
        Me.btnGrid8.Size = New System.Drawing.Size(94, 45)
        Me.btnGrid8.TabIndex = 15
        Me.btnGrid8.Text = "abut"
        Me.btnGrid8.UseVisualStyleBackColor = True
        '
        'btnGrid9
        '
        Me.btnGrid9.Location = New System.Drawing.Point(680, 153)
        Me.btnGrid9.Name = "btnGrid9"
        Me.btnGrid9.Size = New System.Drawing.Size(99, 45)
        Me.btnGrid9.TabIndex = 16
        Me.btnGrid9.Text = "understudy"
        Me.btnGrid9.UseVisualStyleBackColor = True
        '
        'btnGrid10
        '
        Me.btnGrid10.Location = New System.Drawing.Point(877, 153)
        Me.btnGrid10.Name = "btnGrid10"
        Me.btnGrid10.Size = New System.Drawing.Size(98, 45)
        Me.btnGrid10.TabIndex = 17
        Me.btnGrid10.Text = "night"
        Me.btnGrid10.UseVisualStyleBackColor = True
        '
        'btnGrid11
        '
        Me.btnGrid11.Location = New System.Drawing.Point(57, 235)
        Me.btnGrid11.Name = "btnGrid11"
        Me.btnGrid11.Size = New System.Drawing.Size(108, 43)
        Me.btnGrid11.TabIndex = 18
        Me.btnGrid11.Text = "pizza"
        Me.btnGrid11.UseVisualStyleBackColor = True
        '
        'btnGrid12
        '
        Me.btnGrid12.Location = New System.Drawing.Point(260, 235)
        Me.btnGrid12.Name = "btnGrid12"
        Me.btnGrid12.Size = New System.Drawing.Size(110, 43)
        Me.btnGrid12.TabIndex = 19
        Me.btnGrid12.Text = "thorn"
        Me.btnGrid12.UseVisualStyleBackColor = True
        '
        'btnGrid13
        '
        Me.btnGrid13.Location = New System.Drawing.Point(477, 235)
        Me.btnGrid13.Name = "btnGrid13"
        Me.btnGrid13.Size = New System.Drawing.Size(94, 43)
        Me.btnGrid13.TabIndex = 20
        Me.btnGrid13.Text = "military"
        Me.btnGrid13.UseVisualStyleBackColor = True
        '
        'btnGrid14
        '
        Me.btnGrid14.Location = New System.Drawing.Point(680, 235)
        Me.btnGrid14.Name = "btnGrid14"
        Me.btnGrid14.Size = New System.Drawing.Size(93, 43)
        Me.btnGrid14.TabIndex = 21
        Me.btnGrid14.Text = "pygmy"
        Me.btnGrid14.UseVisualStyleBackColor = True
        '
        'btnGrid15
        '
        Me.btnGrid15.Location = New System.Drawing.Point(877, 236)
        Me.btnGrid15.Name = "btnGrid15"
        Me.btnGrid15.Size = New System.Drawing.Size(106, 43)
        Me.btnGrid15.TabIndex = 22
        Me.btnGrid15.Text = "accomodate"
        Me.btnGrid15.UseVisualStyleBackColor = True
        '
        'btnGrid16
        '
        Me.btnGrid16.Location = New System.Drawing.Point(57, 312)
        Me.btnGrid16.Name = "btnGrid16"
        Me.btnGrid16.Size = New System.Drawing.Size(108, 45)
        Me.btnGrid16.TabIndex = 23
        Me.btnGrid16.Text = "rises"
        Me.btnGrid16.UseVisualStyleBackColor = True
        '
        'btnGrid17
        '
        Me.btnGrid17.Location = New System.Drawing.Point(260, 312)
        Me.btnGrid17.Name = "btnGrid17"
        Me.btnGrid17.Size = New System.Drawing.Size(110, 45)
        Me.btnGrid17.TabIndex = 24
        Me.btnGrid17.Text = "elating "
        Me.btnGrid17.UseVisualStyleBackColor = True
        '
        'btnGrid18
        '
        Me.btnGrid18.Location = New System.Drawing.Point(477, 312)
        Me.btnGrid18.Name = "btnGrid18"
        Me.btnGrid18.Size = New System.Drawing.Size(94, 45)
        Me.btnGrid18.TabIndex = 25
        Me.btnGrid18.Text = "never"
        Me.btnGrid18.UseVisualStyleBackColor = True
        '
        'btnGrid19
        '
        Me.btnGrid19.Location = New System.Drawing.Point(680, 312)
        Me.btnGrid19.Name = "btnGrid19"
        Me.btnGrid19.Size = New System.Drawing.Size(93, 45)
        Me.btnGrid19.TabIndex = 26
        Me.btnGrid19.Text = "again" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnGrid19.UseVisualStyleBackColor = True
        '
        'btnGrid20
        '
        Me.btnGrid20.Location = New System.Drawing.Point(877, 312)
        Me.btnGrid20.Name = "btnGrid20"
        Me.btnGrid20.Size = New System.Drawing.Size(98, 45)
        Me.btnGrid20.TabIndex = 27
        Me.btnGrid20.Text = "cosmic" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnGrid20.UseVisualStyleBackColor = True
        '
        'btnGrid21
        '
        Me.btnGrid21.Location = New System.Drawing.Point(1047, 74)
        Me.btnGrid21.Name = "btnGrid21"
        Me.btnGrid21.Size = New System.Drawing.Size(98, 46)
        Me.btnGrid21.TabIndex = 28
        Me.btnGrid21.Text = "submission"
        Me.btnGrid21.UseVisualStyleBackColor = True
        '
        'btnGrid22
        '
        Me.btnGrid22.Location = New System.Drawing.Point(1044, 149)
        Me.btnGrid22.Name = "btnGrid22"
        Me.btnGrid22.Size = New System.Drawing.Size(98, 45)
        Me.btnGrid22.TabIndex = 29
        Me.btnGrid22.Text = "couscous"
        Me.btnGrid22.UseVisualStyleBackColor = True
        '
        'btnGrid23
        '
        Me.btnGrid23.Location = New System.Drawing.Point(1047, 235)
        Me.btnGrid23.Name = "btnGrid23"
        Me.btnGrid23.Size = New System.Drawing.Size(98, 45)
        Me.btnGrid23.TabIndex = 30
        Me.btnGrid23.Text = "wintry"
        Me.btnGrid23.UseVisualStyleBackColor = True
        '
        'btnGrid24
        '
        Me.btnGrid24.Location = New System.Drawing.Point(1047, 312)
        Me.btnGrid24.Name = "btnGrid24"
        Me.btnGrid24.Size = New System.Drawing.Size(98, 45)
        Me.btnGrid24.TabIndex = 31
        Me.btnGrid24.Text = "queue" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        Me.btnGrid24.UseVisualStyleBackColor = True
        '
        'btnStart
        '
        Me.btnStart.BackColor = System.Drawing.SystemColors.ControlDark
        Me.btnStart.Location = New System.Drawing.Point(392, 606)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(179, 83)
        Me.btnStart.TabIndex = 32
        Me.btnStart.Text = "Solve"
        Me.btnStart.UseVisualStyleBackColor = False
        '
        'txtCheck
        '
        Me.txtCheck.Location = New System.Drawing.Point(599, 634)
        Me.txtCheck.Name = "txtCheck"
        Me.txtCheck.Size = New System.Drawing.Size(294, 26)
        Me.txtCheck.TabIndex = 33
        Me.txtCheck.Visible = False
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(917, 636)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(90, 30)
        Me.Button1.TabIndex = 34
        Me.Button1.Text = "BtnCheck"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'frmGrideye
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1218, 714)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtCheck)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.btnGrid24)
        Me.Controls.Add(Me.btnGrid23)
        Me.Controls.Add(Me.btnGrid22)
        Me.Controls.Add(Me.btnGrid21)
        Me.Controls.Add(Me.btnGrid20)
        Me.Controls.Add(Me.btnGrid19)
        Me.Controls.Add(Me.btnGrid18)
        Me.Controls.Add(Me.btnGrid17)
        Me.Controls.Add(Me.btnGrid16)
        Me.Controls.Add(Me.btnGrid15)
        Me.Controls.Add(Me.btnGrid14)
        Me.Controls.Add(Me.btnGrid13)
        Me.Controls.Add(Me.btnGrid12)
        Me.Controls.Add(Me.btnGrid11)
        Me.Controls.Add(Me.btnGrid10)
        Me.Controls.Add(Me.btnGrid9)
        Me.Controls.Add(Me.btnGrid8)
        Me.Controls.Add(Me.btnGrid7)
        Me.Controls.Add(Me.btnGrid6)
        Me.Controls.Add(Me.btnGrid5)
        Me.Controls.Add(Me.btnGrid4)
        Me.Controls.Add(Me.btnGrid3)
        Me.Controls.Add(Me.btnGrid2)
        Me.Controls.Add(Me.btnGrid1)
        Me.Controls.Add(Me.BtnReset)
        Me.Controls.Add(Me.BtnGridBack)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.txtHint)
        Me.Controls.Add(Me.btnNext)
        Me.Controls.Add(Me.btnPrevious)
        Me.Controls.Add(Me.lblGridEye)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "frmGrideye"
        Me.Tag = ""
        Me.Text = "Grideye Puzzle"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblGridEye As Label
    Friend WithEvents btnPrevious As Button
    Friend WithEvents btnNext As Button
    Friend WithEvents txtHint As TextBox
    Friend WithEvents btnBack As Button
    Friend WithEvents BtnGridBack As Button
    Friend WithEvents BtnReset As Button
    Friend WithEvents btnGrid1 As Button
    Friend WithEvents btnGrid2 As Button
    Friend WithEvents btnGrid3 As Button
    Friend WithEvents btnGrid4 As Button
    Friend WithEvents btnGrid5 As Button
    Friend WithEvents btnGrid6 As Button
    Friend WithEvents btnGrid7 As Button
    Friend WithEvents btnGrid8 As Button
    Friend WithEvents btnGrid9 As Button
    Friend WithEvents btnGrid10 As Button
    Friend WithEvents btnGrid11 As Button
    Friend WithEvents btnGrid12 As Button
    Friend WithEvents btnGrid13 As Button
    Friend WithEvents btnGrid14 As Button
    Friend WithEvents btnGrid15 As Button
    Friend WithEvents btnGrid16 As Button
    Friend WithEvents btnGrid17 As Button
    Friend WithEvents btnGrid18 As Button
    Friend WithEvents btnGrid19 As Button
    Friend WithEvents btnGrid20 As Button
    Friend WithEvents btnGrid21 As Button
    Friend WithEvents btnGrid22 As Button
    Friend WithEvents btnGrid23 As Button
    Friend WithEvents btnGrid24 As Button
    Friend WithEvents btnStart As Button
    Friend WithEvents txtCheck As TextBox
    Friend WithEvents Button1 As Button
End Class
