﻿Public Class frmGrideye
    Dim strcon As String = "Provider=Microsoft.Jet.OLEDB.4.0; User ID=Admin; Data Source=C:\Users\Viper Coltelli\Downloads\Idunnoman_4\Idunnoman\Idunnoman\Idunnoman.mdb;"
    Dim conn As New OleDb.OleDbConnection(strcon)
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles BtnReset.Click

    End Sub

    Private Sub BtnGridBack_Click(sender As Object, e As EventArgs) Handles BtnGridBack.Click
        Dim SecondForm As New TruthorDare
        SecondForm.Show()
        Me.Hide()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles btnStart.Click
        conn.Open()

        Dim sql As String ' write a sql query to pull the string from the corresponding Truth from the database
        sql = "SELECT gridword FROM Grideye"
        Dim words As Array
        Dim Word As String
        Dim cmd As New OleDb.OleDbCommand(sql, conn)
        Dim reader As OleDb.OleDbDataReader
        reader = cmd.ExecuteReader
        reader.Read()
        Dim x As Integer
        x = 0

        While reader.Read()
            reader.GetValue(x)
            Word = reader.ToString()
            words += words(Word)
            x = x + 1
        End While

        conn.Close()



    End Sub

    Private Sub btnGrid22_Click(sender As Object, e As EventArgs) Handles btnGrid22.Click

    End Sub

    Private Sub btnGrid17_Click(sender As Object, e As EventArgs) Handles btnGrid17.Click

    End Sub

    Private Sub btnGrid18_Click(sender As Object, e As EventArgs) Handles btnGrid18.Click

    End Sub


    Private Sub btnNext_Click(sender As Object, e As EventArgs) Handles btnNext.Click
        Dim GetRandomHint As Integer

        conn.Open()

        GetRandomHint = Int((21 * Rnd()) + 1)

        Dim sql As String ' write a sql query to pull the string from the corresponding clue from the database
        sql = "SELECT gridclue FROM Grideye WHERE gridid = " & GetRandomHint & "" ' query gets data entry where the ID equals the random number generated
        Dim cmd As New OleDb.OleDbCommand(sql, conn)
        Dim reader As OleDb.OleDbDataReader
        reader = cmd.ExecuteReader
        reader.Read()
        txtHint.Text = reader.GetValue(0)
        conn.Close()

        txtCheck.Visible = True


    End Sub

    Private Sub txtHint_TextChanged(sender As Object, e As EventArgs) Handles txtHint.TextChanged

    End Sub

    Private Sub btnPrevious_Click(sender As Object, e As EventArgs) Handles btnPrevious.Click
        Dim GetRandomHint As Integer

        conn.Open()

        GetRandomHint = Int((21 * Rnd()) + 1)

        Dim sql As String ' write a sql query to pull the string from the corresponding clue from the database
        sql = "SELECT gridclue FROM Grideye WHERE gridid = " & GetRandomHint & "" ' query gets data entry where the ID equals the random number generated
        Dim cmd As New OleDb.OleDbCommand(sql, conn)
        Dim reader As OleDb.OleDbDataReader
        reader = cmd.ExecuteReader
        reader.Read()
        txtHint.Text = reader.GetValue(0)
        conn.Close()
    End Sub

    Private Sub btnGrid11_Click(sender As Object, e As EventArgs) Handles btnGrid11.Click

    End Sub

    Private Sub Button1_Click_1(sender As Object, e As EventArgs) Handles Button1.Click
        txtHint.Text = "Congradulations you got it right!"
    End Sub

    Private Sub btnGrid1_Click(sender As Object, e As EventArgs) Handles btnGrid1.Click
        btnGrid1.Visible = False
    End Sub
End Class
