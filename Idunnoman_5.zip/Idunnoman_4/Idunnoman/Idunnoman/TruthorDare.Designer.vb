﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class TruthorDare
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.btnReport = New System.Windows.Forms.Button()
        Me.btnDare = New System.Windows.Forms.Button()
        Me.btnTruth = New System.Windows.Forms.Button()
        Me.btnSettings = New System.Windows.Forms.Button()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.txtDisplay = New System.Windows.Forms.TextBox()
        Me.IdunnomanInfo = New Idunnoman.IdunnomanInfo()
        Me.DareBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.DareTableAdapter = New Idunnoman.IdunnomanInfoTableAdapters.DareTableAdapter()
        Me.TableAdapterManager = New Idunnoman.IdunnomanInfoTableAdapters.TableAdapterManager()
        Me.TruthTableAdapter = New Idunnoman.IdunnomanInfoTableAdapters.TruthTableAdapter()
        Me.TruthBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        CType(Me.IdunnomanInfo, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DareBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TruthBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'btnReport
        '
        Me.btnReport.Location = New System.Drawing.Point(513, 418)
        Me.btnReport.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnReport.Name = "btnReport"
        Me.btnReport.Size = New System.Drawing.Size(171, 45)
        Me.btnReport.TabIndex = 2
        Me.btnReport.Text = "Report A Problem"
        Me.btnReport.UseVisualStyleBackColor = True
        '
        'btnDare
        '
        Me.btnDare.BackColor = System.Drawing.Color.Red
        Me.btnDare.Location = New System.Drawing.Point(891, 391)
        Me.btnDare.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnDare.Name = "btnDare"
        Me.btnDare.Size = New System.Drawing.Size(152, 143)
        Me.btnDare.TabIndex = 3
        Me.btnDare.Text = "Dare"
        Me.btnDare.UseVisualStyleBackColor = False
        '
        'btnTruth
        '
        Me.btnTruth.BackColor = System.Drawing.Color.Salmon
        Me.btnTruth.Location = New System.Drawing.Point(183, 391)
        Me.btnTruth.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnTruth.Name = "btnTruth"
        Me.btnTruth.Size = New System.Drawing.Size(148, 143)
        Me.btnTruth.TabIndex = 4
        Me.btnTruth.Text = "Truth"
        Me.btnTruth.UseVisualStyleBackColor = False
        '
        'btnSettings
        '
        Me.btnSettings.Location = New System.Drawing.Point(513, 488)
        Me.btnSettings.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnSettings.Name = "btnSettings"
        Me.btnSettings.Size = New System.Drawing.Size(171, 46)
        Me.btnSettings.TabIndex = 5
        Me.btnSettings.Text = "Settings"
        Me.btnSettings.UseVisualStyleBackColor = True
        '
        'btnBack
        '
        Me.btnBack.BackColor = System.Drawing.Color.LightSalmon
        Me.btnBack.Location = New System.Drawing.Point(-2, -2)
        Me.btnBack.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(112, 35)
        Me.btnBack.TabIndex = 6
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = False
        '
        'txtDisplay
        '
        Me.txtDisplay.Location = New System.Drawing.Point(183, 45)
        Me.txtDisplay.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.txtDisplay.Multiline = True
        Me.txtDisplay.Name = "txtDisplay"
        Me.txtDisplay.Size = New System.Drawing.Size(858, 301)
        Me.txtDisplay.TabIndex = 7
        Me.txtDisplay.Text = "" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "                                                                   " &
    "              Truth or Dare goes here"
        '
        'IdunnomanInfo
        '
        Me.IdunnomanInfo.DataSetName = "IdunnomanInfo"
        Me.IdunnomanInfo.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DareBindingSource
        '
        Me.DareBindingSource.DataMember = "Dare"
        Me.DareBindingSource.DataSource = Me.IdunnomanInfo
        '
        'DareTableAdapter
        '
        Me.DareTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.DareTableAdapter = Me.DareTableAdapter
        Me.TableAdapterManager.GrideyequotesTableAdapter = Nothing
        Me.TableAdapterManager.GrideyeTableAdapter = Nothing
        Me.TableAdapterManager.TruthTableAdapter = Me.TruthTableAdapter
        Me.TableAdapterManager.UpdateOrder = Idunnoman.IdunnomanInfoTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'TruthTableAdapter
        '
        Me.TruthTableAdapter.ClearBeforeFill = True
        '
        'TruthBindingSource
        '
        Me.TruthBindingSource.DataMember = "Truth"
        Me.TruthBindingSource.DataSource = Me.IdunnomanInfo
        '
        'TruthorDare
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1200, 692)
        Me.Controls.Add(Me.txtDisplay)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.btnSettings)
        Me.Controls.Add(Me.btnTruth)
        Me.Controls.Add(Me.btnDare)
        Me.Controls.Add(Me.btnReport)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "TruthorDare"
        Me.Text = "TruthorDare"
        CType(Me.IdunnomanInfo, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DareBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TruthBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnReport As Button
    Friend WithEvents btnDare As Button
    Friend WithEvents btnTruth As Button
    Friend WithEvents btnSettings As Button
    Friend WithEvents btnBack As Button
    Friend WithEvents txtDisplay As TextBox
    Friend WithEvents IdunnomanInfo As IdunnomanInfo
    Friend WithEvents DareBindingSource As BindingSource
    Friend WithEvents DareTableAdapter As IdunnomanInfoTableAdapters.DareTableAdapter
    Friend WithEvents TableAdapterManager As IdunnomanInfoTableAdapters.TableAdapterManager
    Friend WithEvents TruthTableAdapter As IdunnomanInfoTableAdapters.TruthTableAdapter
    Friend WithEvents TruthBindingSource As BindingSource
End Class
