﻿Public Class SettingsToD
    Private Sub btnBack2_Click(sender As Object, e As EventArgs) Handles btnBack2.Click
        Dim SecondForm As New TruthorDare
        SecondForm.Show()
        Me.Hide()
    End Sub
End Class