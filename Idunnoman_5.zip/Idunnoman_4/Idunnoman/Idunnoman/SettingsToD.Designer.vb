﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SettingsToD
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnDarkmode = New System.Windows.Forms.Button()
        Me.btnLanguage = New System.Windows.Forms.Button()
        Me.btnSubmit = New System.Windows.Forms.Button()
        Me.btnAbout = New System.Windows.Forms.Button()
        Me.btnBack2 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnDarkmode
        '
        Me.btnDarkmode.Location = New System.Drawing.Point(64, 67)
        Me.btnDarkmode.Name = "btnDarkmode"
        Me.btnDarkmode.Size = New System.Drawing.Size(245, 35)
        Me.btnDarkmode.TabIndex = 0
        Me.btnDarkmode.Text = "Change to Dark Mode?"
        Me.btnDarkmode.UseVisualStyleBackColor = True
        '
        'btnLanguage
        '
        Me.btnLanguage.Location = New System.Drawing.Point(64, 118)
        Me.btnLanguage.Name = "btnLanguage"
        Me.btnLanguage.Size = New System.Drawing.Size(245, 34)
        Me.btnLanguage.TabIndex = 1
        Me.btnLanguage.Text = "Language Settings"
        Me.btnLanguage.UseVisualStyleBackColor = True
        '
        'btnSubmit
        '
        Me.btnSubmit.Location = New System.Drawing.Point(64, 169)
        Me.btnSubmit.Name = "btnSubmit"
        Me.btnSubmit.Size = New System.Drawing.Size(245, 35)
        Me.btnSubmit.TabIndex = 2
        Me.btnSubmit.Text = "Submit a Truth or a Dare"
        Me.btnSubmit.UseVisualStyleBackColor = True
        '
        'btnAbout
        '
        Me.btnAbout.Location = New System.Drawing.Point(64, 219)
        Me.btnAbout.Name = "btnAbout"
        Me.btnAbout.Size = New System.Drawing.Size(245, 37)
        Me.btnAbout.TabIndex = 3
        Me.btnAbout.Text = "About"
        Me.btnAbout.UseVisualStyleBackColor = True
        '
        'btnBack2
        '
        Me.btnBack2.Location = New System.Drawing.Point(0, -1)
        Me.btnBack2.Name = "btnBack2"
        Me.btnBack2.Size = New System.Drawing.Size(75, 23)
        Me.btnBack2.TabIndex = 4
        Me.btnBack2.Text = "Back"
        Me.btnBack2.UseVisualStyleBackColor = True
        '
        'SettingsToD
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(370, 295)
        Me.Controls.Add(Me.btnBack2)
        Me.Controls.Add(Me.btnAbout)
        Me.Controls.Add(Me.btnSubmit)
        Me.Controls.Add(Me.btnLanguage)
        Me.Controls.Add(Me.btnDarkmode)
        Me.Name = "SettingsToD"
        Me.Text = "Settings Truth or Dare"
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents btnDarkmode As Button
    Friend WithEvents btnLanguage As Button
    Friend WithEvents btnSubmit As Button
    Friend WithEvents btnAbout As Button
    Friend WithEvents btnBack2 As Button
End Class
