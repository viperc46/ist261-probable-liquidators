﻿Public Class TruthorDare
    Dim strcon As String = "Provider=Microsoft.Jet.OLEDB.4.0; User ID=Admin; Data Source=C:\Users\Viper Coltelli\Downloads\Idunnoman_4\Idunnoman\Idunnoman\Idunnoman.mdb;"
    Dim conn As New OleDb.OleDbConnection(strcon)

    Private Sub btnTruth_Click(sender As Object, e As EventArgs) Handles btnTruth.Click
        Dim GetRandomTruth As Integer
        conn.Open()

        GetRandomTruth = Int((10 * Rnd()) + 1) 'pull a random number between 1 and maxlength

        Dim sql As String ' write a sql query to pull the string from the corresponding Truth from the database
        sql = "SELECT truth FROM truth WHERE truthid = " & GetRandomTruth & "" ' query gets data entry where the ID equals the random number generated
        Dim cmd As New OleDb.OleDbCommand(sql, conn)
        Dim reader As OleDb.OleDbDataReader
        reader = cmd.ExecuteReader
        reader.Read()
        txtDisplay.Text = reader.GetValue(0)
        conn.Close()
    End Sub

    Private Sub btnDare_Click(sender As Object, e As EventArgs) Handles btnDare.Click
        Dim GetRandomDare As Integer
        conn.Open()

        GetRandomDare = Int((10 * Rnd()) + 1) 'pull a random number between 1 and maxlength

        Dim sql As String ' write a sql query to pull the string from the corresponding Truth from the database
        sql = "SELECT dare FROM dare WHERE dareid = " & GetRandomDare & "" ' query gets data entry where the ID equals the random number generated
        Dim cmd As New OleDb.OleDbCommand(sql, conn)
        Dim reader As OleDb.OleDbDataReader
        reader = cmd.ExecuteReader
        reader.Read()
        txtDisplay.Text = reader.GetValue(0)

        conn.Close()
    End Sub
    Private Sub btnBack_Click(sender As Object, e As EventArgs) Handles btnBack.Click
        Dim SecondForm As New frmGrideye
        SecondForm.Show()
        Me.Hide()
    End Sub

    Private Sub btnSettings_Click(sender As Object, e As EventArgs) Handles btnSettings.Click
        Dim SecondForm As New SettingsToD
        SecondForm.Show()
        Me.Hide()
    End Sub



    Private Sub DareBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.DareBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.IdunnomanInfo)

    End Sub

    Private Sub TruthorDare_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'IdunnomanInfo.Truth' table. You can move, or remove it, as needed.
        Me.TruthTableAdapter.Fill(Me.IdunnomanInfo.Truth)
        'TODO: This line of code loads data into the 'IdunnomanInfo.Dare' table. You can move, or remove it, as needed.
        Me.DareTableAdapter.Fill(Me.IdunnomanInfo.Dare)

    End Sub

    Private Sub TRUTHIDTextBox_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub TRUTHIDLabel_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub txtDisplay_TextChanged(sender As Object, e As EventArgs) Handles txtDisplay.TextChanged

    End Sub
End Class